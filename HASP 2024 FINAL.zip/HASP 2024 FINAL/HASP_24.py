#! /usr/bin/python3

#### IMPORTS ####

from Camera import Camera
from Motor import Motor
from Digital import Digital
from TempSensors import TempSensors
from GuiderModule import *
from Utils import *

import RPi.GPIO as GPIO
import cv2

import time
from threading import Thread

#### GLOBAL VARIABLES ####

PIN_MOTOR_X_ENA = 24
PIN_MOTOR_X_STEP = 25
PIN_MOTOR_X_DIR = 12
PIN_MOTOR_Y_ENA = 18
PIN_MOTOR_Y_STEP = 6
PIN_MOTOR_Y_DIR = 16
PIN_LIMIT_SWITCH_CW = 13
PIN_LIMIT_SWITCH_CCW = 19
PIN_LIMIT_SWICTH_UP = 20
PIN_LIMIT_SWICTH_DOWN = 26
PIN_PHOTODIODE_N = 5
PIN_PHOTODIODE_E = 22
PIN_PHOTODIODE_S = 27
PIN_PHOTODIODE_W = 17
PIN_TEMP = 4

MotorStepDelay = 1000
MotorCurrentRun = 31
MotorCurrentHold = 31
MotorMicrosteps = 1
MotorSPIBus = 0
MotorASPIDevice = 1
MotorBSPIDevice = 0
MotorSPISpeed = 2000000
Motor_UP = 1
Motor_DOWN = 0
Motor_CW = 1
Motor_CCW = 0
pixels_to_step_X = 35
pixels_to_step_Y = 10

CameraDLLPath = "/home/hasp2024/Downloads/ASI_Camera_SDK/ASI_linux_mac_SDK_V1.33/lib/armv8/libASICamera2.so"
GuideCameraExposure = 1000
GuideCameraGain = 500
GuideCameraResX = 3840
GuideCameraResY = 2160
GuideCameraId = 1
ScienceCameraExposure = 1000
ScienceCameraGain = 500
ScienceCaameraResX = 3840
ScienceCameraResY = 2160
ScienceCameraId = 0

TempSensorsNum = 4

DeltaGMT = 6 # HOURS

SaveThreadLoopDelay = 1 # SECONDS
InputThreadLoopDelay = 1 # SECONDS
OutputThreadLoopDelay = 1 # SECONDS
MainThreadLoopDelay = 1 # SECONDS

# DO NOT EDIT
system_var = None
dir_X = None
dir_Y = None
homing_X_CW_1_done = False
homing_X_CW_2_done = False
homing_X_CCW_1_done = False
homing_X_CCW_2_done = False
homing_Y_UP_1_done = False
homing_Y_UP_2_done = False
homing_Y_DOWN_1_done = False
homing_Y_DOWN_2_done = False
photodiode_detection_done = False

motorX = None
motorY = None
guidecamera = None
sciencecamera = None
limitswitches = None
photodiodes = None
tempsensors = None

GPS_time_data = [] # [[TIME(days) TIME(hours) LONGTITTUDE(degrees) LATITUDE(degrees)],...]
images = []

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#### FUNCTIONS ####

def save_images():
    global images
    num_saved = 0
    while True:
        imgs_size = len(images)
        if(imgs_size>0):
            filename = f"SUN{num_saved}.jpg"
            cv2.imwrite(filename,images[imgs_size-1])
            del(images[:imgs_size])
            num_saved+=1
        time.sleep(SaveThreadLoopDelay)

def output():
    pass

def input():
    pass

def callback_CW(channel):
    global system_var
    global homing_X_CW_1
    global photodiode_detection_done
    global dir_X
    motorX.Interrupt()
    match system_var:
        case "HOMING":
            if(not homing_X_CW_1):
                homing_X_CW_1 = True
        case "PHOTODIODE_PAN":
            photodiode_detection_done = True
        case "HUNT":
            if(dir_X != Motor_CCW):
                dir_X = Motor_CCW
                motorY.Run(20, dir_Y, 1000)
        case _:
            pass
        
def callback_CCW(channel):
    global system_var
    global homing_X_CCW_1
    global dir_X
    motorX.Interrupt()
    match system_var:
        case "HOMING":
            if(not homing_X_CCW_1):
                homing_X_CCW_1 = True
        case "HUNT":
            if(dir_X != Motor_CW):
                dir_X = Motor_CW
                motorY(20, dir_Y, 1000)
        case _:
            pass

def callback_UP(channel):
    global system_var
    global homing_Y_UP_1
    global dir_Y
    motorY.Interrupt()
    match system_var:
        case "HOMING":
            if(not homing_Y_UP_1):
                homing_Y_UP_1 = True
        case "HUNT":
            dir_Y = Motor_DOWN
        case _:
            pass

def callback_DOWN(channel):
    global system_var
    global homing_Y_DOWN_1
    global dir_Y
    motorY.Interrupt()
    match system_var:
        case "HOMING":
            if(not homing_Y_DOWN_1):
                homing_Y_DOWN_1 = True
        case "HUNT":
            dir_Y = Motor_UP
        case _:
            pass

def main_thread():
    global system_var
    global dir_X
    global dir_Y
    global homing_X_CW_1_done
    global homing_X_CW_2_done
    global homing_X_CCW_1_done
    global homing_X_CCW_2_done
    global homing_Y_UP_1_done
    global homing_Y_UP_2_done
    global homing_Y_DOWN_1_done
    global homing_Y_DOWN_2_done
    global photodiode_detection_done

    global motorX
    global motorY
    global guidecamera
    global sciencecamera
    global limitswitches
    global photodiodes
    global tempsensors

    global GPS_time_data
    global images

    motorX = Motor(PIN_MOTOR_X_ENA,
                    PIN_MOTOR_X_STEP,
                    PIN_MOTOR_X_DIR,
                    MotorSPIBus, 
                    MotorASPIDevice, 
                    MotorSPISpeed, 
                    MotorCurrentRun, 
                    MotorCurrentHold, 
                    MotorMicrosteps)
    motorY = Motor(PIN_MOTOR_Y_ENA, 
                   PIN_MOTOR_Y_STEP, 
                   PIN_MOTOR_Y_DIR, 
                   MotorSPIBus, 
                   MotorBSPIDevice, 
                   MotorSPISpeed, 
                   MotorCurrentRun, 
                   MotorCurrentHold, 
                   MotorMicrosteps)

    guidecamera = Camera(GuideCameraGain, 
                         GuideCameraExposure, 
                         GuideCameraResX,
                         GuideCameraResY,
                         GuideCameraId)
    sciencecamera = Camera(ScienceCameraGain, 
                           ScienceCameraExposure, 
                           ScienceCaameraResX,
                           ScienceCameraResY,
                           ScienceCameraId)

    limitswitches = [Digital(PIN_LIMIT_SWITCH_CW),
                     Digital(PIN_LIMIT_SWITCH_CCW),
                     Digital(PIN_LIMIT_SWICTH_UP),
                     Digital(PIN_LIMIT_SWICTH_DOWN)]
    
    photodiodes = [Digital(PIN_PHOTODIODE_N),
                   Digital(PIN_PHOTODIODE_E),
                   Digital(PIN_PHOTODIODE_S),
                   Digital(PIN_PHOTODIODE_W)]

    tempsensors = TempSensors(PIN_TEMP,TempSensorsNum)

    while (motorX.Init() != 0):
        print("Failed to initialize motor X! Retrying...")
        DelaySeconds(1)
    while (motorY.Init() != 0):
        print("Failed to initialize motor Y! Retrying...")
        DelaySeconds(1)
    print("Successfully initialized motors!")
    while(guidecamera.Init(CameraDLLPath) != 0):
        print("Failed to initialize guide camera! Retrying...")
        DelaySeconds(1)
    while(sciencecamera.Init(CameraDLLPath) != 0):
        print("Failed to initialize science camera! Retrying...")
        DelaySeconds(1)
    print("Successfully initialized cameras")
    for limitswitch in limitswitches:
        while (limitswitch.Init() != 0):
            print("Failed to initialize limit switch! Retrying...")
            DelaySeconds(1)
    print("Successfully initialized limit switches")
    for photodiode in photodiodes:
        while (photodiode.Init() != 0):
            print("Failed to initialize photo diode! Retrying...")
            DelaySeconds(1)
    print("Successfully initialized photodiodes")
    while(tempsensors.Init() != 0):
        print("Failed to initialize photo diode! Retrying...")
        DelaySeconds(1)

    save_images_thread = Thread(target = save_images, args = ())
    input_thread = Thread(target = input, args = ())
    output_thread = Thread(target = output, args = ())

    save_images_thread.start()
    input_thread.start()
    output_thread.start()

    GPIO.add_event_detect(PIN_LIMIT_SWITCH_CW, GPIO.FALLING, callback = callback_CW)
    GPIO.add_event_detect(PIN_LIMIT_SWITCH_CCW, GPIO.FALLING, callback = callback_CCW)
    GPIO.add_event_detect(PIN_LIMIT_SWICTH_UP, GPIO.FALLING, callback = callback_UP)
    GPIO.add_event_detect(PIN_LIMIT_SWICTH_DOWN, GPIO.FALLING, callback = callback_DOWN)

    system_var = "HOMING" # globals
    dir_X = Motor_CW # globals
    dir_Y = Motor_UP # globals

    while (True):
        match system_var:
            case "HOMING":
                if(limitswitches[0]==0):
                    motorX.Run(100, Motor_CCW, 10000)
                if(limitswitches[1]==0):
                    motorX.Run(100, Motor_CW, 10000)
                if(limitswitches[2]==0):
                    motorY.Run(20, Motor_DOWN, 10000)
                if(limitswitches[3]==0):
                    motorY.Run(20, Motor_UP, 10000)

                while not homing_X_CW_1_done: # LOOPS STOPS ECECUTING WHEN CALLBACK IS CALLED BY LIMIT SWITCH
                    motorX.Run(100, Motor_CW, 10000)
                motorX.Run(100, Motor_CCW, 10000)
                motorX.Run(100, Motor_CW, 10000)
                homing_X_CW_2 = True
                
                while not homing_X_CCW_1_done: # LOOPS STOPS ECECUTING WHEN CALLBACK IS CALLED BY LIMIT SWITCH
                    motorX.Run(100, Motor_CCW, 10000)
                motorX.Run(100, Motor_CW, 10000)
                motorX.Run(100, Motor_CCW, 10000)
                homing_X_CCW_2 = True
                
                while not homing_Y_UP_1_done: # LOOPS STOPS ECECUTING WHEN CALLBACK IS CALLED BY LIMIT SWITCH
                    motorY.Run(20, Motor_UP, 10000)
                motorY.Run(20, Motor_DOWN, 10000)
                motorY.Run(20, Motor_UP, 10000)
                homing_Y_UP_2 = True
                
                while not homing_Y_DOWN_1_done: # LOOPS STOPS ECECUTING WHEN CALLBACK IS CALLED BY LIMIT SWITCH
                    motorY.Run(20,Motor_DOWN,10000)
                motorY.Run(20,Motor_UP,10000)
                motorY.Run(20,Motor_DOWN,10000)
                homing_Y_DOWN_2 = True
                
                system_var = "ELEVATE"
            case "ELEVATE":
                elevate_data = []

                for i in range(3): # NUMBER OF TIMES ONE WANTS TO CHECK
                    GPS_time_data_saved = len(GPS_time_data)
                    if(GPS_time_data_saved>0):
                        elevate_data = GPS_time_data[GPS_time_data_saved-1]
                        del(GPS_time_data[:GPS_time_data_saved])
                        break
                    DelaySeconds(1) # TIME TO WAIT BEFORE CHECKING AGAIN IN SECONDS
                
                if(len(elevate_data) > 0):
                    altitude = GetSunPosition(DeltaGMT, elevate_data[0], elevate_data[1], elevate_data[2], elevate_data[3]) # FIX
                    steps_altitude = int(altitude*600/360)
                    motorY.Run(steps_altitude, Motor_UP, 1000)

                system_var = "PHOTODIODE_PAN"
            case "PHOTODIODE_PAN":
                while not photodiode_detection_done:
                    if(photodiodes[0]==0):
                        break
                    motorX.Run(100, Motor_CW, 10000) # TIME TO WAIT BEFORE CHECKING AGAIN IN SECONDS
                    DelaySeconds(1)

                system_var = "HUNT"
            case "HUNT":
                guide_img, guide_stat = guidecamera.get_image()
                guide_img_error_properties = calculate_coord(guide_img)

                if(guide_img_error_properties[0]!=None):
                    within_x_tol = abs(guide_img_error_properties[0]) < pixels_to_step_X
                    within_y_tol = abs(guide_img_error_properties[1]) < pixels_to_step_Y
                    
                    if(not within_x_tol):
                        if(guide_img_error_properties[0]/abs(guide_img_error_properties[0])):
                            dir_X = Motor_CW
                        else:
                            dir_X = Motor_CCW
                        steps_X = int(abs(guide_img_error_properties[0]/pixels_to_step_X))
                        motorX.Run(steps_X, dir_X, 10000)

                    if(not within_y_tol):
                        if(guide_img_error_properties[1]/abs(guide_img_error_properties[1])):
                            dir_Y = Motor_UP
                        else:
                            dir_Y = Motor_DOWN
                        steps_Y = int(abs(guide_img_error_properties[1]/pixels_to_step_Y))
                        motorY.Run(steps_Y, dir_Y, 10000)

                    if(within_x_tol and within_y_tol):
                        science_img, science_stat = sciencecamera.get_image()
                        images.append(science_img)
                else:
                    motorX.Run(100, dir_X, 10000)
            case _:
                pass
        DelaySeconds(MainThreadLoopDelay)